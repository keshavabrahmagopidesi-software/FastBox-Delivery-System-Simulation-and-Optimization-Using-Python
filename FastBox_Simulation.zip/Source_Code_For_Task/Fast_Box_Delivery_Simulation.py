import json
import math
import os
import csv
import random
from tkinter import Tk, filedialog

# Function to calculate Euclidean distance
def calculate_distance(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

# Function to print ASCII route
def print_route(agent_id, warehouse_id, destination):
    print(f"\nRoute Visualization:")
    print(f"{agent_id} ---> {warehouse_id} ---> {destination}")

try:
    # Open file manager to select JSON file
    Tk().withdraw()
    input_file = filedialog.askopenfilename(
        title="Select Input JSON File",
        filetypes=[("JSON Files", "*.json")]
    )

    if not input_file:
        raise FileNotFoundError("No file selected")

    # Read JSON file
    with open(input_file, "r") as file:
        data = json.load(file)

    # Normalize warehouses
    warehouses = {}
    if isinstance(data["warehouses"], list):
        for w in data["warehouses"]:
            warehouses[w["id"]] = w["location"]
    else:
        warehouses = data["warehouses"]

    # Normalize agents
    agents = {}
    if isinstance(data["agents"], list):
        for a in data["agents"]:
            agents[a["id"]] = a["location"]
    else:
        agents = data["agents"]

    packages = data["packages"]

    # Initialize report
    report = {}
    for agent_id in agents:
        report[agent_id] = {
            "packages_delivered": 0,
            "total_distance": 0.0,
            "total_delay": 0
        }

    # Assign packages to nearest agent
    for package in packages:
        warehouse_id = package["warehouse_id"] if "warehouse_id" in package else package["warehouse"]
        warehouse_location = warehouses[warehouse_id]

        nearest_agent = None
        min_distance = float("inf")

        for agent_id, agent_location in agents.items():
            distance = calculate_distance(agent_location, warehouse_location)
            if distance < min_distance:
                min_distance = distance
                nearest_agent = agent_id

        destination = package["destination"]

        travel_distance = (
            calculate_distance(agents[nearest_agent], warehouse_location) +
            calculate_distance(warehouse_location, destination)
        )

        # Random delay between 1 and 10 minutes
        delay = random.randint(1, 10)

        report[nearest_agent]["packages_delivered"] += 1
        report[nearest_agent]["total_distance"] += travel_distance
        report[nearest_agent]["total_delay"] += delay

        # ASCII route visualization
        print_route(nearest_agent, warehouse_id, destination)

    # Calculate efficiency and best agent
    best_agent = None
    best_efficiency = float("inf")

    for agent_id, details in report.items():
        if details["packages_delivered"] == 0:
            details["efficiency"] = 0
            continue

        efficiency = details["total_distance"] / details["packages_delivered"]
        details["total_distance"] = round(details["total_distance"], 2)
        details["efficiency"] = round(efficiency, 2)

        if efficiency < best_efficiency:
            best_efficiency = efficiency
            best_agent = agent_id

    report["best_agent"] = best_agent

    # Create output file names
    input_folder = os.path.dirname(input_file)
    input_name = os.path.splitext(os.path.basename(input_file))[0]

    json_output_path = os.path.join(input_folder, f"{input_name}_report.json")
    csv_output_path = os.path.join(input_folder, f"{input_name}_best_agent.csv")

    # Save JSON report
    with open(json_output_path, "w") as file:
        json.dump(report, file, indent=4)

    # Export best agent to CSV
    if best_agent:
        with open(csv_output_path, "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["agent_id", "packages_delivered", "total_distance", "efficiency", "total_delay"])
            writer.writerow([
                best_agent,
                report[best_agent]["packages_delivered"],
                report[best_agent]["total_distance"],
                report[best_agent]["efficiency"],
                report[best_agent]["total_delay"]
            ])

    print("\nDelivery simulation completed successfully")
    print("JSON Report saved at:")
    print(json_output_path)
    print("Best agent CSV saved at:")
    print(csv_output_path)

except FileNotFoundError as e:
    print("Error:", e)

except json.JSONDecodeError:
    print("Error: Invalid JSON format")

except KeyError as e:
    print("Error: Missing key in JSON ->", e)

except Exception as e:
    print("Unexpected error occurred:")
    print(e)
